package jogo;

import reaccao.Accao;
import reaccao.Estimulo;

public interface Comportamento {
	
	public Accao activar (Estimulo estimulo);

}
