package reaccao;

public interface Accao {
	public void executar ();
}
