package reaccao;

public interface Estimulo {

}
